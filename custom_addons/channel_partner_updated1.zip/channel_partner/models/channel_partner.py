from odoo import models, fields,api,_
from odoo.exceptions import ValidationError




class ChannelPartner(models.Model):
    _name = 'channel.partner'

    # channel partner details

    first_name = fields.Char(string='First Name', required=True)
    last_name = fields.Char(string='Last Name', )
    email = fields.Char(string='Email', required=True)
    pan = fields.Char(string='PAN',)
    mobile_number = fields.Char(string='Mobile Number', )
    landline_number = fields.Char(string='Landline Number')

    # Address and Region Information
    communication_address = fields.Text(string='Communication Address', )
    professional_relationship_details = fields.Text(string='Proffesional Details')
    region_of_operation = fields.Char(string='Region of Operation in India')


    # Company Information
    company_name = fields.Char(string='Name of the Company')
    pan_card_number = fields.Char(string='PAN Card No.')
    website_url = fields.Char(string='Website Address (URL)')
    registered_address = fields.Text(string='Registered Address')

    rera_registration = fields.Char(string='RERA Registration No', )
    scanned_cheque_file = fields.Binary(string='Cheque', attachment=True, )
    gst_number = fields.Char(string='GST No',)
    pan_scan_file = fields.Binary(string='PAN Scan File', attachment=True)

    c_partner_id = fields.Char(string='C Partner ID', readonly=True)
    file_name = fields.Char('File Name')





    @api.model
    def create(self, vals):
        # Generate C Partner ID and assign it to the record being created
        vals['c_partner_id'] = self._generate_c_partner_id(vals.get('pan', ''))
        return super(ChannelPartner, self).create(vals)



    def _generate_c_partner_id(self, pan):
        # Helper function to generate C Partner ID
        if pan and len(pan) >= 4:
            last_four_digits = pan[-4:]
            current_year_last_two_digits = str(fields.Date.today().year)[-2:]
            c_partner_id = f"UBCP{current_year_last_two_digits}{last_four_digits}".upper()

            # Check for existing records with the same last four digits
            existing_records = self.search([('pan', 'like', f'%{last_four_digits}')])
            if existing_records:
                raise ValidationError(_('User already exists with similar PAN.'))

            return c_partner_id
        else:
            raise ValidationError(_('PAN is required to generate a C Partner ID.'))




    # Checkboxes
    credai = fields.Boolean(string='CREDAI')
    rera = fields.Boolean(string='RERA')

    other = fields.Boolean(string='OTHER')

    @api.onchange('pan')
    def _onchange_pan(self):
        if self.pan:
            self.pan = self.pan.upper()





class ChannelCrmAdd(models.Model):

    _inherit = 'crm.lead'

    channel_partner_id = fields.Char(string='Channel Partner')