from odoo import models, fields,api

class SchoolModel(models.Model):
    _name = 'school.module'


